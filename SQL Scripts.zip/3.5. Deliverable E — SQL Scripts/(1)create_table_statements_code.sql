    DROP TABLE IF EXISTS COUNTRY_METRIC;
    DROP TABLE IF EXISTS LATEST_NEWS;
    DROP TABLE IF EXISTS RESOURCES;
    DROP TABLE IF EXISTS COUNTRY_FUNDING_PARTNERS;
    DROP TABLE IF EXISTS FUNDING_PARTNERS;
    DROP TABLE IF EXISTS LOCAL_PARTNERS;
    DROP TABLE IF EXISTS OUR_WORK;
    DROP TABLE IF EXISTS OVERVIEW;
    DROP TABLE IF EXISTS COUNTRY;
    DROP TABLE IF EXISTS METRIC;
    DROP TABLE IF EXISTS CONTINENT;



    CREATE TABLE CONTINENT (
        continent_id INTEGER PRIMARY KEY,
        continent_name VARCHAR(100) NOT NULL
    );

    CREATE TABLE COUNTRY (
        country_id INTEGER PRIMARY KEY,
        country_name VARCHAR(100) NOT NULL,
        continent_id INTEGER,
        FOREIGN KEY (continent_id) REFERENCES CONTINENT(continent_id)
    );

    CREATE TABLE OVERVIEW (
        overview_id INTEGER PRIMARY KEY,
        country_id INTEGER,
        overview_description VARCHAR(2000),
        impact VARCHAR(500),
        contact_name VARCHAR(100),
        contact_email VARCHAR (100),
        FOREIGN KEY (country_id) REFERENCES COUNTRY(country_id)
    );

    CREATE TABLE OUR_WORK (
        ourwork_id INTEGER PRIMARY KEY,
        country_id INTEGER,
        why_description VARCHAR(2000),
        work_description VARCHAR(1000),
        programme_areas VARCHAR(500),
        FOREIGN KEY (country_id) REFERENCES COUNTRY(country_id)
    );



    CREATE TABLE LOCAL_PARTNERS (
        local_partner_id INTEGER PRIMARY KEY,
        country_id INTEGER,
        partner_name VARCHAR(100),
        FOREIGN KEY (country_id) REFERENCES COUNTRY(country_id)
    );


    CREATE TABLE FUNDING_PARTNERS (
        funding_partner_id INTEGER PRIMARY KEY,
        partner_name VARCHAR(100)
    );

    CREATE TABLE COUNTRY_FUNDING_PARTNERS (
        country_id INTEGER,
        funding_partner_id INTEGER,
        PRIMARY KEY (country_id, funding_partner_id),
        FOREIGN KEY (country_id) REFERENCES COUNTRY(country_id),
        FOREIGN KEY (funding_partner_id) REFERENCES FUNDING_PARTNERS(funding_partner_id)
    );

    CREATE TABLE RESOURCES (
        resources_id INTEGER PRIMARY KEY,
        country_id INTEGER,
        resource_title VARCHAR(200),
        resource_type VARCHAR(200),
        resource_date VARCHAR(50),
        FOREIGN KEY (country_id) REFERENCES COUNTRY(country_id)
    );

    CREATE TABLE LATEST_NEWS (
        latestnews_id INTEGER PRIMARY KEY,
        country_id INTEGER,
        news_title VARCHAR (200),
        news_author VARCHAR(50),
        news_date VARCHAR(50),    
        FOREIGN KEY (country_id) REFERENCES COUNTRY(country_id)
    );

    CREATE TABLE METRIC (
        metric_id INTEGER PRIMARY KEY,
        metric_name VARCHAR (100),
        metric_description VARCHAR (200)
    );

    CREATE TABLE COUNTRY_METRIC (
        country_id INTEGER,
        metric_id INTEGER,
        PRIMARY KEY (country_id, metric_id),
        FOREIGN KEY (country_id) REFERENCES COUNTRY(country_id),
        FOREIGN KEY (metric_id) REFERENCES METRIC(metric_id)
    );