INSERT INTO `CONTINENT`(continent_id, continent_name)
    VALUES
        (21, 'Africa'),
        (22, 'Central America'),
        (23, 'Middle East'),
        (20, 'Asia')
;

INSERT INTO `COUNTRY`(country_id, country_name, continent_id)
    VALUES
        (11, 'Sierra Leone', 21),
        (12, 'South Sudan', 21),
        (13, 'Somalia', 21),
        (14, 'Ethiopia', 21),
        (15, 'Rwanda', 21),
        (16, 'Malawi', 21),
        (17, 'Guatemala', 22),
        (18, 'Honduras', 22),
        (19, 'Palestine', 23),
        (10, 'Myanmar', 20)
;

INSERT INTO `OVERVIEW`(overview_id, country_id, overview_description, impact, contact_name, contact_email)
    VALUES
        (31, 11, 'Sierra Leone is one of the poorest countries in the world. It has been affected by the legacy and trauma of a brutal civil war, as well as a devastating ebola outbreak...',
         '40,000 people received agricultural support. 22,000 people supported through Womens Empowerment programmes. 1,000 people supported with humanitarian aid.',
          'George Were', 'george.were@trocaire.org'),
        (32, 12, 'South Sudan is the world''s newest nation since it became independent from Sudan in 2011. It is also one of Africa''s most diverse countries over 60 different ethnic groups...',
        '12,000 people supported with humanitarian aid. Trócaire began working in South Sudan in 1976.',
        '',''),
        (33, 13, 'Ravaged by conflict, drought and hunger, Somalia is one of the poorest and most fragile countries in the world...',
        '19,000 people treated at Trócaire health centres every month. 218,000 number of people reached with humanitarian support. 1992 the year Trócaire established operations in Somalia.',
        'Paul Healy', 'infosomalia@trocaire.org'),
        (34, 14, 'Ethiopia is Africa''s oldest independent country and one of the largest in terms of population. It has changed rapidly since the dark days of the 1980s when civil war led to a devastating famine...', 
        '679,000 people supported in 2019. 119,000 people received agricultural support. 91% of women we work with have their own source of income.',
        'Teamrat Belai', 'teamrat.belai@trocaire.org'),
        (35, 15, 'Known as ''the land of a thousand hills'', Rwanda is one of the smallest and most densely populated countries in Africa. Rwanda has undergone a remarkable transformation over the past few decades...',
        '8,000 people supported with humanitarian aid. 17,000 people receiving agricultural support. 7,000 people supported by our Women''s Empowerment programme.',
        'Marleen Masclee', 'inforwanda@trocaire.org'),
        (36, 16, 'Malawi is a small, densely populated country in southern Africa. It is particularly vulnerable to the impact of climate change and experiences these more frequently...',
        '65,000 people supported with humanitarian aid. 79,000 people received agricultural support. 37,000 people supported through women''s empowerment programmes.',
        'Wamuyu Manyara','wamuyu.manyara@trocaire.org'),
        (37, 17, 'Guatemala has one of the highest rates of poverty and inequality in Latin America and one of the highest levels of child malnutrition in the world.',
        '21,000 people supported with humanitarian assistance. 15,000 people supported through access to justice programmes. 5,000 people supported through women''s empowerment. 11,000 people supported through resource rights projects.',
        'Martin Larrecochea','inforguatemala@trocaire.org'),
        (38, 18, 'Honduras is one of the least developed and most unequal countries in Central America. Despite its valuable natural resources...',
        '22,000 people supported with humanitarian aid. 12,000 people supported through resource rights & access to justice. 9,000 people supported through women''s empowerment',
        'George Redman','infohonduras@trocaire.org'),
        (39, 19, 'The year 2025 marks 58 years of occupation of the Palestinian territory (oPt) and 18 years of the siege and blockade of the Gaza Strip. It has become increasingly clear that Israel has no intention of relinquishing control...',
        '21,000 people supported through our partners. 7,000 people supported with humanitarian aid. 13,000 people supported through access to justice projects. 1,000 people supported through women''s empowerment',
        'Hervé Bund','infoopti@trocaire.org'),
        (30, 10, 'The people of Myanmar are facing an unprecedented political, socioeconomic and humanitarian crisis with needs escalating dramatically since the military takeover and a severe COVID-19 third wave in 2021...',
        '62,000 people supported with humanitarian assistance. 18,000 people supported to access and make use of land and other natural resources. 9,000 people supported through women''s empowerment projects',
        '', 'infomyanmar@trocaire.org')
;

INSERT INTO `OUR_WORK`(ourwork_id, country_id, why_description, work_description, programme_areas)
    VALUES
        (41, 11, 'Sierra Leone is one of the poorest countries in the world, ranked 181 out of 189 countries on the Human Development Index...',
         'Trócaire has supported programmes in Sierra Leone since the 1980s, focusing on women''s empowerment...',
         '1. Food and Resource Rights. 2. Women''s Empowerment'),
        (42, 12, 'Trócaire has been in the region since 1976. We now jointly programme with our UK sister agency CAFOD.', 
         'Supported 71,928 people to cope with climate change, protecting food supplies, increasing livelihoods...',
         '1. Emergency response. 2. Supporting women and girls'),
         (43, 13, 'Somalia is one of the poorest countries of the world. It is also a very complex and fragile country, which had no effective government from 1991 until 2012...',
         'Trócaire began working in Somalia in 1992 when the country was experiencing famine. We established our programmes in the Gedo region, where we have stayed ever since...',
         '1. Healthcare. 2. Education. 3. Nutrition. 4. 4. Humanitarian Response. 5. 5. Protection'),
         (44 , 14, 'Trócaire has worked in Ethiopia for almost 50 years. Since 2009, we have worked in partnership with 2 sister agencies from the UK and Scotland...',
         'Food, farming & the environment: 3,498 women, men, and youth participated in savings group projects in Addis, South Omo, Tigray, and Borena...', ''),
         (45 , 15, 'Trócaire began working in Rwanda in the aftermath of the genocide in 1994. We have stayed ever since. For the last three decades Trócaire has been working with the most vulnerable groups in the country...',
         '13,067 people supported to cope with climate change, protecting food supplies, increasing livelihoods. 4,815 women and girls supported with protection, raising voices, creating leaders...',
         '1. Women & girls- safer, participating, leading. 2. Saving lives & protecting human dignity.'),
         (46 , 16, 'With your support, Trócaire is building resilient communities in Malawi. We provide emergency support during natural disasters. We tackle hunger and violence against women...',
         'Supported 138,833 people to cope with climate change, protecting food supplies, increasing livelihoods...',
         '1. Women & Girls- safer, participating, leading. 2. Emergency response.'),
         (47 , 17, 'Thanks to your support, Trócaire is helping communities in Guatemala to defend their fundamental freedoms and protect their land in the face of corporate greed...',
         'Supported 17,703 to defend their human rights and get access to justice...',
         '1. Women & Girls- safer, participating, leading. 2. Emergency response.'),
         (48 , 18, 'Trócaire has been working in Honduras since 1973, and opened a country office in 1994. Thanks to your support Trócaire is helping communities in Honduras to protect their land in the face of corporate greed...',
         'Supported 16,639 to defend their human rights and get access to justice...',
         '1. Defending human rights. 2. Protecting human rights & environmental defenders.'),
         (49 , 19, 'The situation in the occupied Palestinian territory (oPt) today is one of immense humanitarian need and disregard for the protection of civilians in line with international human rights and humanitarian law.',
         'Trócaire has worked in the occupied Palestinian territory since 2002 and we continue to work with a range of Palestinian and Israeli local civil society and church partners...', ''),
         (40 , 10, 'Myanmar (formerly Burma) is a country in transition. Despite the economy opening up, it remains an incredibly unequal and divided society... ',
         'Trócaire''s programmes in Myanmar focus on: women''s empowerment, resource & land rights, peace building, governance, humanitarian response and emergency preparedness...',
         '1. Humanitarian.  2. Land & Resource Rights. 3. Women''s Empowerment. 4. Governance and Access to Justice.')
;

INSERT INTO `LOCAL_PARTNERS`(local_partner_id, country_id, partner_name)
    VALUES
        (5110, 11, "Action for Advocacy and Development"),
        (5111, 11, "AdvocAid"),
        (5112, 11, "Association for the Well-Being of Rural Communities & Development"),
        (5113, 11, "Campaign for Good Governance"),
        (5114, 11, "Caritas Sierra Leone"),
        (5115, 11, "Caritas Makeni"),
        (5116, 11, "Caritas Freetown /Justice & Peace Commission"),
        (5117, 11, "Centre for Accountability & Rule of Law"),
        (5118, 11, "Centre for Democracy and Human Rights"),
        (5119, 11, "Community Action to Restore Lives")
;

INSERT INTO `FUNDING_PARTNERS`(funding_partner_id, partner_name)
    VALUES
        (5120, 'Irish Aid'),
        (5121, 'European Union'),
        (5122, 'Vastenactie'),
        (5123, 'States of Guernsey Overseas Aid Development Commission'),
        (5124, 'Electric Aid'),
        (5125, 'Irish Consortium on Gender Based Violence'),
        (5126, 'MISEREOR'),
        (5127, 'Secours Catholique'),
        (5128, 'Start Fund Network')
;


INSERT INTO `COUNTRY_FUNDING_PARTNERS`(country_id, funding_partner_id)
    VALUES
        (11, 5120),
        (11, 5121),
        (11, 5122),
        (11, 5123),
        (11, 5124),
        (11, 5125),
        (11, 5126),
        (12, 5120),
        (12, 5127),
        (12, 5128)        
;

INSERT INTO `RESOURCES`(resources_id, country_id, resource_title, resource_type, resource_date)
    VALUES
        (610, 11, 'Toolkit for Community Psychosocial Support Workers', 'Policy and Programmes', '09 March 2017'),
        (611, 11, 'Education for girls in Sierra Leone', 'Education', '18 June 2018'),
        (612, 11, 'Understanding Women''s Lives in Polygamous Marriages: Exploring Community Perspectives in Sierra Leone and DRC', 'Policy and Programmes', '03 August 2017'),
        (613, 12, 'Empowering Yirol East Communities through Village Saving and Loan Associations', 'Policy and Programmes', '29 March 2023'),
        (614, 12, 'Trocaire Capacity Statement – Responding to Covid 19', 'Policy and Programmes', '25 June 2020'),
        (615, 12, 'Trócaire''s Humanitarian Policy & Strategy', 'Policy and Programmes', '26 October 2016'),
        (616, 13, 'Rebuilding Resilience through Income Generating Activities in Somalia', 'Policy and Programmes', '24 October 2018'),
        (617, 13, 'Joint statement: Health and Nutrition Consortium Somalia – March 2017', 'Policy and Programmes', '13 March 2017'),
        (618, 13, 'Somalia''s struggle towards peace', 'Policy and Programmes', '05 September 2013'),
        (619, 14, 'Hunger: The Real Reasons. A Focus on Ethiopia', 'Education', '28 August 2013')
;

INSERT INTO `LATEST_NEWS`(latestnews_id, country_id, news_title, news_author, news_date)
    VALUES
        (710, 11, 'Bridging the Gap: How the European Union is Promoting Gender Equality in Sierra Leone', 'Trócaire', '03 July 2025'),
        (711, 11, 'Land, business and…bees!', 'Trócaire', '19 May 2025'),
        (712, 11, 'Clean water and a healthier community in Sierra Leone', 'Trócaire', '04 July 2024'),
        (713, 11, 'One Day: Women are leaders in Sierra Leone', 'Catherine Devine ', '19 July 2023'),
        (714, 11, 'Hawa Dumbuya – first female councillor sets sights on becoming first female president of Sierra Leone', 'Catherine Devine', '06 June 2023'),
        (715, 11, 'Turn up the volume: Irish Aid funded women''s radio station empowering the women of Sierra Leone', 'Catherine Devine', '13 February 2023'),
        (716, 11, '2022 – Looking back on our journey for global justice', 'Caoimhe de Barra', '20 December 2022'),
        (717, 11, 'Sierra Leone moves to bring more women into politics with new gender quotas in parliament', 'Catherine Devine', '22 November 2022'),
        (718, 11, 'Sierra Leone passes ''globally unprecedented'' laws to boost landowners'' rights', 'Catherine Devine', '03 November 2022'),
        (719, 11, 'Women farmers unite to strengthen their rights in Sierra Leone', 'Trócaire', '28 July 2022')
;

INSERT INTO `METRIC`(metric_id, metric_name, metric_description)
    VALUES
        (81, 'Human Development Index', 'Ranked 181 out of 189 countries'),
        (82, 'Life expectancy', '54 years'),
        (83, 'Poverty', '58% live in poverty'),
        (84, 'UN Human Development Index Ranking', 'Ranked 193 out of 193 countries'),
        (85, 'Maternal Deaths per 100,000', '1,223 deaths per 100,000 births'),
        (86, 'Life expectancy', '58 Years Old'),
        (87, 'Expected Years of School for Children', '6'),
        (88, 'Population', '15 million'),
        (89, 'Life expectancy', '57 years'),
        (80, 'Poverty', '69% live in poverty')
;

INSERT INTO`COUNTRY_METRIC`(country_id, metric_id)
    VALUES 
        (11, 81),
        (11, 82),
        (11, 83),
        (12, 84),
        (12, 85),
        (12, 86),
        (12, 87),
        (13, 88),
        (13, 89),
        (13, 80)
;
