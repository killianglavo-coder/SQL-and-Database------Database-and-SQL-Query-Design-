
-- Query 1: Donator
SELECT
    F.partner_name AS Funding_Partner,
    C.country_name AS Country,
    CO.continent_name AS Continent,
    O.overview_description AS Overview,
    O.impact AS Impact,
    OW.why_description AS Why,
    OW.work_description AS Work,
    IFNULL(LP.partner_name,'N/A') AS Local_Partner
FROM
    FUNDING_PARTNERS F
JOIN
    COUNTRY_FUNDING_PARTNERS CFP ON F.funding_partner_id = CFP.funding_partner_id
JOIN
    COUNTRY C ON C.country_id = CFP.country_id
JOIN
    CONTINENT CO ON C.continent_id = CO.continent_id
LEFT JOIN
    OVERVIEW O ON C.country_id = O.country_id
LEFT JOIN
    OUR_WORK OW ON C.country_id = OW.country_id
LEFT JOIN
    LOCAL_PARTNERS LP ON C.country_id = LP.country_id
GROUP BY
    F.partner_name, C.country_name;

--Query 2: Volunteers
SELECT
    CO.continent_name AS Continent,
    C.country_name AS Country,
    OW.why_description AS Why_This_Work,
    OW.work_description AS Description,
    OW.programme_areas AS Programme_Areas
FROM
    OUR_WORK OW
JOIN
    COUNTRY C ON OW.country_id = C.country_id
JOIN
    CONTINENT CO ON C.continent_id = CO.continent_id
ORDER BY
    CO.continent_name, C.country_name;

--Query 3: General Public

SELECT
    CO.continent_name AS Continent,
    C.country_name AS Country,
    M.metric_name AS Metric,
    M.metric_description AS Metric_Description
FROM
    COUNTRY C
JOIN
    CONTINENT CO ON C.continent_id = CO.continent_id
LEFT JOIN
    COUNTRY_METRIC CM ON C.country_id = CM.country_id
LEFT JOIN
    METRIC M ON CM.metric_id = M.metric_id
WHERE
    M.metric_id IS NOT NULL
ORDER BY
    CO.continent_name, C.country_name, M.metric_name;

--Query 4: Beneficiaries

SELECT
    C.country_name AS Country,
    LN.news_title AS News_Title,
    LN.news_author AS Author,
    LN.news_date AS News_Date,
    OW.work_description AS Description,
    OW.programme_areas AS Programme_Areas
FROM
    COUNTRY C
LEFT JOIN
    LATEST_NEWS LN ON C.country_id = LN.country_id
LEFT JOIN
    OUR_WORK OW ON C.country_id = OW.country_id
WHERE LN.country_id IS NOT NULL
ORDER BY
    C.country_name, LN.news_date DESC;

--Query 5: Journalists

SELECT
    C.country_name AS Country,
    LN.news_title,
    LN.news_date,
    LN.news_author,
    
    OW.work_description AS Work_Description,
    OW.why_description AS Why_we_work_here,
    OW.programme_areas AS Programmes
FROM
    COUNTRY C
LEFT JOIN
    LATEST_NEWS LN ON C.country_id = LN.country_id

LEFT JOIN
    OUR_WORK OW ON C.country_id = OW.country_id
WHERE country_name LIKE 'Sierra%'
AND LN.news_date IS NOT NULL
;